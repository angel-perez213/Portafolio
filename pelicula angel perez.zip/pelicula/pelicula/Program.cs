﻿using System;

namespace pelicula
{
    public class Pelicula
    {
        private string nombre;
        private double duracion;
        private Genero genero;
        private int anio;
        private double calificacion;
        public Pelicula(string nombre, double duracion, Genero genero, int anio)
        {
            this.nombre = nombre;
            this.duracion = duracion;
            this.genero = genero;
            this.anio = anio;
            this.calificacion = 0;
        }
        public double Calificacion
        {
            get { return calificacion; }
            set { calificacion = value; }
        }
        public void ImprimirInformacion()
        {
            Console.WriteLine("Nombre: {0}", nombre);
            Console.WriteLine("Duración: {0} horas", duracion);
            Console.WriteLine("Género: {0}", genero);
            Console.WriteLine("Año: {0}", anio);
            Console.WriteLine("Calificación: {0}", calificacion);
        }

        public bool esPeliculaEpica()
        {
            return duracion >= 3;
        }

        public bool esSimilar(Pelicula otraPelicula)
        {
            return genero == otraPelicula.genero && calificacion == otraPelicula.calificacion;
        }

        public string ObtenerValoracion()
        {
            if (calificacion >= 9)
            {
                return "Excelente";
            }
            else if (calificacion >= 7.5)
            {
                return "Muy buena";
            }
            else if (calificacion >= 6)
            {
                return "Buena";
            }
            else if (calificacion >= 5)
            {
                return "Regular";
            }
            else
            {
                return "Mala";
            }
        }
    }

    public enum Genero
    {
        ACCION,
        COMEDIA,
        DRAMA,
        SUSPENSO
    }

    public class Program
    {
        public static void Main()
        {
            Pelicula pelicula1 = new Pelicula("The Lord of the Rings", 2.75, Genero.ACCION, 2001);
            Pelicula pelicula2 = new Pelicula("The Shawshank Redemption", 2.22, Genero.DRAMA, 1994);
            pelicula1.Calificacion = 8.5;
            Console.WriteLine("Información de la primera película:");
            pelicula1.ImprimirInformacion();

            Console.WriteLine();

            Console.WriteLine("Información de la segunda película:");
            pelicula2.ImprimirInformacion();

            Console.WriteLine();
            if (pelicula1.esPeliculaEpica())
            {
                Console.WriteLine("La primera película es épica");
            }
            else
            {
                Console.WriteLine("La primera película no es épica");
            }

            Console.WriteLine();

            if (pelicula1.esSimilar(pelicula2))
            {
                Console.WriteLine("Las películas son similares");
            }
            else
            {
                Console.WriteLine("Las películas no son similares");
            }
            Console.WriteLine();
            string valoracion = pelicula1.ObtenerValoracion();
            Console.WriteLine("Valoración de la primera película: {0}", valoracion);
        }
    }
}
