﻿using System;

namespace ejercicio_semana_7
{
    internal class Program
    {
            static void Main(string[] args)
            {
                double est;
                double sum = 0;
                char respuesta;
                int cont = 0;

                do
                {
                    Console.WriteLine("Ingrese una estatura");
                    est = Convert.ToDouble(Console.ReadLine());
                    sum += est;
                    cont++;

                repetir:
                    Console.WriteLine("Desea ingresar otra estarura? s = sí, n = no");
                    respuesta = Convert.ToChar(Console.ReadLine());
                    if (respuesta != 's' && respuesta != 'n')
                    {
                        goto repetir;
                    }
                } while (respuesta == 's');
                double promedio = sum / cont;
                Console.WriteLine("El promedio es " + promedio);
            }
        }
    }

