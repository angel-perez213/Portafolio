﻿using System;

namespace Matrices_IntroProgra
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] calificaciones = new int[30, 6]; // declaramos una matriz para almacenar las calificaciones

            // le pedimos al usuario que ingrese las calificaciones de los alumnos
            for (int i = 0; i < 30; i++)
            {
                Console.WriteLine($"Ingrese las calificaciones del alumno {i + 1}: ");
                for (int j = 0; j < 6; j++)
                {
                    Console.Write($"Asignatura {j + 1}: ");
                    calificaciones[i, j] = int.Parse(Console.ReadLine());
                }
            }

            // calculamos la media de notas por alumno y por asignatura
            double[] mediaPorAlumno = new double[30];
            double[] mediaPorAsignatura = new double[6];

            for (int i = 0; i < 30; i++)
            {
                double sum = 0;
                for (int j = 0; j < 6; j++)
                {
                    sum += calificaciones[i, j];
                    mediaPorAsignatura[j] += calificaciones[i, j];
                }
                mediaPorAlumno[i] = sum / 6.0;
            }

            for (int j = 0; j < 6; j++)
            {
                mediaPorAsignatura[j] /= 30.0;
            }

            // mostramos en pantalla la media de notas por alumno y por asignatura
            Console.WriteLine("\nMedia de notas por alumno:");
            for (int i = 0; i < 30; i++)
            {
                Console.WriteLine($"Alumno {i + 1}: {mediaPorAlumno[i]}");
            }

            Console.WriteLine("\nMedia de notas por asignatura:");
            for (int j = 0; j < 6; j++)
            {
                Console.WriteLine($"Asignatura {j + 1}: {mediaPorAsignatura[j]}");
            }
        }
    }
}
